import numpy as np
from lmfit.models import (VoigtModel)  # pip install lmfit
import matplotlib.pyplot as plt
import pandas as pd
import csv
import os
from scipy import interpolate
from make_dictionary import fit
from baselinewavelet import baselineWavelet
from scipy.sparse import csc_matrix, eye, diags
# from baselineCorrection import baseline_als
from scipy.stats import norm


def pre_data(x, y):
	f1 = interpolate.interp1d(x, y, kind='linear')  # 插值模块
	x_pred = np.linspace(65, 1700, num=1636)
	y_pred = f1(x_pred)

	return x_pred, y_pred

def cosine_similarity(x, y):#余弦相似度
    num = x.dot(y.T)
    denom = np.linalg.norm(x) * np.linalg.norm(y)
    n=num / denom
    if n>1:n=1.0
    return n


def judge(data):
	y=data
	path = "./lib-spectra/"  # 数据库中存储物质的光谱
	path_list = os.listdir(path)
	path_list.sort()  # 对读取的路径进行排序
	num=-1#判断是哪一种物质
	
	for j in range(len(path_list)):
		with open(path + path_list[j], 'r') as csvfile:
			x = np.loadtxt(csvfile)
			for i in range(len(x)):
				x[i]=float(x[i])

			x=np.mat(x)
			cos=cosine_similarity(x, y)
			#print(cos)
			if cos>0.9:
				num=j
				
	return num


def signal():
	# f=50 hz
	print('Generating simulated experiment')
	
	x=np.arange(0,1000,1)
	#x = np.arange(60, 1801, 1)
	g1=norm(loc = 100, scale = 1.0) # generate three gaussian as a signal
	g2=norm(loc = 200, scale = 3.0)
	g3=norm(loc = 750, scale = 5.0)
	g4 = norm(loc=550, scale=4.0)
	g5 = norm(loc=350, scale=8.0)
	
	signal=10000*(g1.pdf(x)+g2.pdf(x)+g3.pdf(x)+g4.pdf(x)+g5.pdf(x))
	baseline=10000*(0.015*np.sin(np.pi*x*5/x.max())+0.025*np.cos(np.pi*x*3/x.max()))+1000 # sinusoidal baseline
	noise=np.random.random(x.shape[0])/500
	
	y_origin=signal
	y=signal+baseline+noise

	# plt.plot(y)
	# plt.figure()
	# plt.plot(y_origin)
	# plt.show()
	return x,y_origin,y


if __name__ == '__main__':
	# x,y_origin,fp=signal()
	# np.savetxt('./test/test1.txt', y_origin)
	# np.savetxt('./test/test.txt',fp)
	# z = baseline_als(10,0.00001,100,fp)
	# y2=fp-z
	# y2[y2 < 0] = 0
	# y2 = np.array(y2)
	# plt.plot(y2)
	# plt.show()
	# y22, matrix2 = fit(x,y2)
	# matrix2 = pd.DataFrame(matrix2)
	# matrix2.to_csv('./test/peak.csv', header=None)
	data_name='F:/laman/小拉曼/对乙酰氨基酚/dy-1s-1-50mw-10.csv'
	x = np.arange(65, 1701, 1)

	with open(data_name, 'r') as csvfile:
		reader = csv.reader(csvfile)
		data = [row[1] for row in reader]  #
	for i in range(len(data)):
		data[i] = float(data[i])
	with open(data_name, 'r') as csvfile:
		reader = csv.reader(csvfile)
		xp = [row[0] for row in reader]  #
	for i in range(len(xp)):
		xp[i] = float(xp[i])

	fp=data
	x,y=pre_data(xp,fp)
	for i in range(335):  # 去除过小的杂乱信号
		y[i] = 0
	yp = y
	y = np.mat(y)
	num=judge(y)

	if num<0:
		n = [num]
		print('该物质的字典不在数据库中')
		np.savetxt('./test/num.txt', n)
		np.savetxt('./test/test.txt',yp)
		y2 = baselineWavelet(yp)
		y2[y2 < 0] = 0
		y2 = np.array(y2)
		y22, matrix2,p = fit(x,y2)
		matrix2 = pd.DataFrame(matrix2)
		matrix2.to_csv('./test/peak.csv', header=None)
	print(num)
	if num >= 0:
		n=[num]
		np.savetxt('./test/num.txt', n)
		print('该物质的字典在数据库中')
		np.savetxt('./test/test.txt',yp)
		y2 = baselineWavelet(yp)
		y2[y2 < 0] = 0
		y2 = np.array(y2)
		y22, matrix2,p = fit(x,y2)
		path1 = "./标准峰/"  # 字典数据库
		path_list1 = os.listdir(path1)
		path_list1.sort()  # 对读取的路径进行排序
		with open(path1 + path_list1[num], 'r') as csvfile:
			peakp = np.loadtxt(csvfile)
		for i in range (len(p)):
			p[i]=p[i]+65
		peakp_real=np.zeros((1,len(peakp)))
		
		for j in range(len(peakp)):
			for i in range(len(p)):
				if abs(p[i]-peakp[j])<15:
					n=int(p[i]-65)
					intensity=y2[n]
					print(intensity)
					peakp_real[0][j]=intensity

		np.savetxt('./test/peakp.txt', peakp_real)
		path = "./lib/"  # 字典数据库
		path_list = os.listdir(path)
		path_list.sort()  # 对读取的路径进行排序
		df = pd.read_csv(path + path_list[num])
		data = pd.DataFrame(df)  # 将data的行列转换
		data.to_csv('./test/peak.csv', index=False,header=1)